<?php
session_start(); // Start or resume a session

include("site/db.php");
include("site/tribe.php");

// Check if the user is logged in
if (isset($_SESSION['id'])) {
    // User is logged in, retrieve their details
    $user_id = $_SESSION['id'];

    // Retrieve user details from the database based on the user_id
    $stmt_user = $conn->prepare("SELECT name, profile_picture, banned FROM Users WHERE id = ?");
    $stmt_user->bind_param("i", $user_id);
    $stmt_user->execute();
    $stmt_user->store_result();

    if ($stmt_user->num_rows > 0) {
        // User found, fetch details
        $stmt_user->bind_result($username, $profile_picture, $banned);
        $stmt_user->fetch();

        // Check if the user is banned
        if ($banned == 'yes') {
            // Retrieve ban reason from banned_reason table
            $stmt_ban_reason = $conn->prepare("SELECT banned_reason FROM Users WHERE banned = ?");
            $stmt_ban_reason->bind_param("i", $user_id);
            $stmt_ban_reason->execute();
            $stmt_ban_reason->bind_result($ban_reason);
            $stmt_ban_reason->fetch();
            $stmt_ban_reason->close();
        } else {
            // If user is not banned, redirect to dashboard
            header("Location: dash");
            exit();
        }
    } else {
        // User not found, handle this case (e.g., redirect to login)
        header("Location: login.php");
        exit();
    }

    // Close the statement
    $stmt_user->close();
} else {
    // If user is not logged in, redirect to login page
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banned</title>
    <link rel="stylesheet" href="conf.css">
</head>
<body>
    <div class="site">
        <h2>You are banned</h2>
        <p>Reason: <?php echo isset($ban_reason) ? $ban_reason : "Reason not available"; ?></p>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>
