<?php
session_start(); // Start or resume a session

include("site/db.php");
include("site/tribe.php");

// Check if the user is logged in
if(isset($_SESSION['id'])) {
    // User is logged in, retrieve their details
    $user_id = $_SESSION['id'];

    // Retrieve user details from the database based on the user_id
    $stmt_user = $conn->prepare("SELECT name, profile_picture, power, banned FROM Users WHERE id = ?");
    $stmt_user->bind_param("i", $user_id);
    $stmt_user->execute();
    $stmt_user->store_result();

    if ($stmt_user->num_rows > 0) {
        // User found, fetch details
        $stmt_user->bind_result($username, $profile_picture, $power, $banned);
        $stmt_user->fetch();
        
        // Redirect if user is banned
        if ($banned == 'yes') {
            header("Location: banned.php");
            exit;
        }
    } else {
        // User not found, you might want to handle this case
        $username = "Guest";
        $profile_picture = "default_profile.png";
        $power = 0; // Set default power
    }

    // Close the statement
    $stmt_user->close();
} else {
    // User is not logged in, provide default values
    $username = "idk";
    $profile_picture = "";
    $power = 0; // Set default power
}

// Handle logout
if(isset($_POST['logout'])) {
    // Unset all session variables
    $_SESSION = array();

    // Destroy the session
    session_destroy();

    // Redirect to the login page or any other page you want after logout
    header("Location: login");
    exit;
}
?>

<html>
<head>
    <link rel="stylesheet" href="conf.css">
    
    <style>
        .admin-panel {
            position: fixed;
            top: 10px;
            left: 10px;
            background-color: #007bff;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="site">
        <h2>Welcome To Home</h2>  
        <div class="profile">
            <?php
            
            echo '<img src="site/profile/' . $profile_picture . '" alt="Profile Picture">';
            echo '<p>Username: ' . $username . '</p>';
            
            
            if ($power >= 4) {
                echo '<a class="admin-panel" href="user/admin">A - AdminPANEL</a>';
            }
            ?>
          <div class="logout">  
          <form method="post" action="">
              
                <input type="submit" name="logout" value="Logout">
            </form>
            </div>
        </div>
    </div>
</body>
</html>
