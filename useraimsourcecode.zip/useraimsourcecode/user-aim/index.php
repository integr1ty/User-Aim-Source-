<?php
session_start(); // Start or resume a session

include("site/db.php");
include("site/tribe.php");

// Check if the user is already logged in
if (isset($_SESSION['id'])) {
    // Redirect to dashboard if logged in
    header("Location: dash");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Convert the input username to lowercase
    $username_lower = strtolower($username);

    // Check if the user or email already exists
    $stmt_check = $conn->prepare("SELECT id FROM Users WHERE LOWER(name) = ? OR email = ?");
    $stmt_check->bind_param("ss", $username_lower, $email);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
        // User or email already exists, display an error message
        echo "LOL THIS USERNAME OR EMAIL ALREADY BEEN USED.";
    } else {
        // User and email do not exist, proceed with registration

        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO Users (email, name, password, power) VALUES (?, ?, ?, 0)");
        $stmt->bind_param("sss", $email, $username, $hashed_password);

        // Execute the statement
        if ($stmt->execute()) {
            // Registration successful, set session variable for user ID
            $_SESSION['id'] = $stmt->insert_id;
            
            // Redirect to dashboard on success
            header("Location: dash");
            exit();
        } else {
            // Handle error - in production, you'd want to log this and show a user-friendly message
            echo "Error: " . $stmt->error;
        }

        // Close statement and connection
        $stmt->close();
    }

    // Close statement and connection
    $stmt_check->close();
    $conn->close();
}
?>

<html>
<head>
    <link rel="stylesheet" href="conf.css">
</head>
<body>
    <div class="site">
        <h1>REGISTER AT USER-AIM</h1>  
        <form action="" method="POST">
            <input type="email" name="email" placeholder="EMAIL" required>
            <input type="text" name="username" placeholder="USERNAME" required>
            <input type="password" name="password" placeholder="PASSWORD" required>
            <button class="button-site" type="submit">Register</button>
        </form>
    </div>
</body>
</html>
