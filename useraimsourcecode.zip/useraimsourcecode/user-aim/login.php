<?php
session_start(); // Start or resume a session

include("site/db.php");
include("site/tribe.php");

// Check if the user is already logged in
if(isset($_SESSION['id'])) {
    // Redirect to dashboard if logged in
    header("Location: dash.php");
    exit();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare statement to retrieve user information based on username
    $stmt = $conn->prepare("SELECT id, name, password FROM Users WHERE name = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // User found, verify password
        $stmt->bind_result($user_id, $username, $hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            // Password is correct, set session variable for user ID
            $_SESSION['id'] = $user_id;
            
            // Redirect to dashboard on successful login
            header("Location: dash");
            exit();
        } else {
            // Password is incorrect, display error message
            $error_message = "Incorrect password.";
        }
    } else {
        // User not found, display error message
        $error_message = "User not found.";
    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();
?>

<html>
<head>
    <link rel="stylesheet" href="conf.css">

</head>
<body>
    <div class="site">
        <h1>LOGIN AT USER-AIM</h1>  
        <form action="" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button class="button-site" type="submit">Login</button>
        </form>
        <?php
        // Display error message if exists
        if(isset($error_message)) {
            echo "<p>$error_message</p>";
        }
        ?>
        <p>Ya Good Make An Acc BRO! <a href="index.php">SIGNUP IM MAKING THE 3D RENDERS LATER YAP YAP</a>.</p>
    </div>
</body>
</html>
