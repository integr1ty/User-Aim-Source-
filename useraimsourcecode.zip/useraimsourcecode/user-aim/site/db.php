<?php
$servername = "mysql2.serv00.com";
$username = "m3878_omelon";
$password = "kr6zg8+U1RRqKXA_~660h7:VNaS7r~";
$dbname = "m3878_omelon";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
