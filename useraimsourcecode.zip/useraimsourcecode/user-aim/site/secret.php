 <div class="container">
      <h1>Home</h1> 
   
   <h1>Settings</h1>
   
   </div>