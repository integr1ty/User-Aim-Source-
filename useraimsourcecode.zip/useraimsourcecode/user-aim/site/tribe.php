<?php 
  
  header("location: /maintenance");
  
  ?>
<title>User-Aim Beta</title>
<div class="user-img">
  <img src="site/user-aim.png" weight="114" height="116" onclick="window.location.href = '/users'">
    </div>

