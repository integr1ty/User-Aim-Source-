<?php
// Include the database connection file
include("../../site/db.php");

// Function to fetch users from the database
function fetchUsers($conn) {
    $sql = "SELECT id, email, name, profile_picture, password, power, banned, banned_reason FROM Users";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $users = array();
        while($row = $result->fetch_assoc()) {
            $row['banned'] = $row['banned'] ? 'yes' : 'no'; // Convert banned status to 'yes' or 'no'
            $users[] = $row;
        }
        return $users;
    } else {
        return array();
    }
}


// Function to update banned status and reason
function updateBanStatus($conn, $id, $banned, $banned_reason) {
    $banned = $banned === 'yes' ? 1 : 0; // Convert 'yes'/'no' to 1/0
    $sql = "UPDATE Users SET banned=?, banned_reason=? WHERE id=?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isi", $banned, $banned_reason, $id);
    
    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}

// Fetch and display users
$users = fetchUsers($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Management</title>
</head>
<body>
    <h1>User Management</h1>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Email</th>
            <th>Name</th>
            <th>Profile Picture</th>
            <th>Password</th>
            <th>Power</th>
            <th>Banned</th>
            <th>Banned Reason</th>
            <th>Action</th>
        </tr>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?php echo htmlspecialchars($user['id']); ?></td>
            <td><?php echo htmlspecialchars($user['email']); ?></td>
            <td><?php echo htmlspecialchars($user['name']); ?></td>
            <td><?php echo htmlspecialchars($user['profile_picture']); ?></td>
            <td><?php echo htmlspecialchars($user['password']); ?></td>
            <td><?php echo htmlspecialchars($user['power']); ?></td>
            <td><?php echo htmlspecialchars($user['banned']); ?></td>
            <td><?php echo htmlspecialchars($user['banned_reason']); ?></td>
            <td>
                <form method="post" action="update_user.php">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($user['id']); ?>">
                    <select name="banned">
                        <option value="yes" <?php if ($user['banned'] === 'yes') echo 'selected'; ?>>Yes</option>
                        <option value="no" <?php if ($user['banned'] === 'no') echo 'selected'; ?>>No</option>
                    </select>
                    <input type="text" name="banned_reason" value="<?php echo htmlspecialchars($user['banned_reason']); ?>">
                    <input type="submit" value="Update">
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>