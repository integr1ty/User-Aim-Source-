<?php

include("../../site/db.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $banned = $_POST['banned'];
    $banned_reason = $_POST['banned_reason'];

    if (updateBanStatus($conn, $id, $banned, $banned_reason)) {
        echo "User updated successfully.";
    } else {
        echo "Failed to update user.";
    }
}

function updateBanStatus($conn, $id, $banned, $banned_reason) {
    $banned = $banned === 'yes' ? 1 : 0;
    $sql = "UPDATE Users SET banned=?, banned_reason=? WHERE id=?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isi", $banned, $banned_reason, $id);
    
    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
?>
