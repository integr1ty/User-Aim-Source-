<?php
include("site/db.php");

// Fetch user names from the database
$users = array(); // Initialize an empty array to store user names

try {
    // SQL query to select all names from the Users table
    $sql = "SELECT name FROM Users";
    
    // Prepare the statement
    $stmt = $conn->prepare($sql);
    
    // Execute the statement
    $stmt->execute();
    
    // Bind the result variables
    $stmt->bind_result($name);
    
    // Fetch names and store in the array
    while ($stmt->fetch()) {
        $users[] = $name;
    }
} catch(Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>

<html>
<head>
    <link rel="stylesheet" href="conf.css">
    <title>Users</title>
</head>
<body>
    <div class="site">
        <h2>CHECK OUT USERS LOL</h2>  
        <div class="profile">
            <?php
            // Display user names
            foreach ($users as $user) {
                echo '<p>Name: ' . $user . '</p>';
            }
            ?>
        </div>
    </div>
</body>
</html>
